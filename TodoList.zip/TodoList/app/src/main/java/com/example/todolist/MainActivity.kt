package com.example.todolist

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var adapter: TaskAdapter
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("todo_list", Context.MODE_PRIVATE)

        val welcomeTextView: TextView = findViewById(R.id.welcomeTextView)
        welcomeTextView.text = getString(R.string.welcome_message, "Vamshi")

        val addButton: Button = findViewById(R.id.addButton)
        listView = findViewById(R.id.listView)

        adapter = TaskAdapter()
        listView.adapter = adapter

        addButton.setOnClickListener {
            val intent = Intent(this@MainActivity, AddItemActivity::class.java)
            startActivity(intent)
        }

        loadTasks()
    }

    override fun onResume() {
        super.onResume()
        loadTasks()
    }

    private fun loadTasks() {
        val tasks = sharedPreferences.getStringSet(TASKS_KEY, HashSet()) ?: HashSet()
        adapter.clear()
        tasks.forEach { task ->
            // Only add tasks that are not marked as deleted
            if (!sharedPreferences.getBoolean(getCompletionKey(task), false)) {
                adapter.add(task)
            }
        }
        adapter.notifyDataSetChanged()
    }

    inner class TaskAdapter : ArrayAdapter<String>(this@MainActivity, R.layout.task_item, R.id.taskTextView) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.task_item, parent, false)
            val taskTextView = view.findViewById<CheckBox>(R.id.taskTextView)
            val deleteButton = view.findViewById<ImageView>(R.id.deleteButton)

            val task = getItem(position) ?: "" // Provide a default value if getItem(position) is null
            taskTextView.text = task

            // Set the checked state of the checkbox based on the saved completion status
            taskTextView.isChecked = sharedPreferences.getBoolean(getCompletionKey(task), false)

            taskTextView.setOnCheckedChangeListener { _, isChecked ->
                // Save the completion status of the task
                sharedPreferences.edit().putBoolean(getCompletionKey(task), isChecked).apply()
            }

            deleteButton.setOnClickListener {
                val deletedTask = getItem(position) ?: "" // Provide a default value if getItem(position) is null
                remove(deletedTask)
                // Remove both task and its completion status from SharedPreferences
                sharedPreferences.edit().remove(deletedTask).remove(getCompletionKey(deletedTask)).apply()
                notifyDataSetChanged()
            }

            return view
        }
    }

    private fun getCompletionKey(task: String): String {
        return task + "_completed"
    }

    companion object {
        private const val TASKS_KEY = "tasks"
    }
}

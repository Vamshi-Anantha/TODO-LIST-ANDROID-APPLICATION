package com.example.todolist

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class AddItemActivity : AppCompatActivity() {

    companion object {
        private const val TASKS_KEY = "tasks"
        private const val KEY_CHECKBOX_STATES = "checkbox_states"
    }

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_item)

        sharedPreferences = getSharedPreferences("todo_list", Context.MODE_PRIVATE)

        val addButton: Button = findViewById(R.id.addButton)
        val editText: EditText = findViewById(R.id.editText)

        addButton.setOnClickListener {
            val itemText = editText.text.toString().trim()
            if (itemText.isNotBlank()) {
                // Save the changes made before adding the new task
                saveChanges()
                // Save the item to SharedPreferences
                saveItem(itemText)
                val intent = Intent(this@AddItemActivity, MainActivity::class.java)
                startActivity(intent)
                finish() // Finish this activity to prevent going back to it with the back button
            }
        }
    }

    private fun saveItem(item: String) {
        val tasks = sharedPreferences.getStringSet(TASKS_KEY, HashSet()) ?: HashSet()
        tasks.add(item)
        sharedPreferences.edit().putStringSet(TASKS_KEY, tasks).apply()
    }

    private fun saveChanges() {
        val checkBoxStates = mutableMapOf<String, Boolean>()
        // Implement the logic to save checkbox states here
        // For example, you can iterate through your list view and save the state of each checkbox
    }
}
